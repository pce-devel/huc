#define NULL (0)
