#define INT_MAX 32767
#define INT_MIN -32768
#define UINT_MAX 65535
#define __CHAR_BIT__ 8
#define UCHAR_MAX 255
#define SCHAR_MAX 127
