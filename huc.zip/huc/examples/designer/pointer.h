#define EV_NONE 0
#define EV_LEFT_BUTTON_DOWN 1
#define EV_LEFT_BUTTON_UP 2
#define EV_LEFT_BUTTON_HELD 4
#define EV_RIGHT_BUTTON_DOWN 8
#define EV_RIGHT_BUTTON_UP 16
#define EV_RIGHT_BUTTON_HELD 32

extern int mp_x, mp_y;
