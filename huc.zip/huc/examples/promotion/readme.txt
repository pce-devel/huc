This is an example project that shows how to use the tile mapping capabilities
in Cosmigo's ProMotion art package to create a simple tilemap to use with HuC.

The example map uses all 256 HuC tiles, and all 16 of the background palettes.

For more information ...

ProMotion's Color Constraints Checks
https://www.cosmigo.com/promotion/docs/onlinehelp/ColorConstraints.htm

ProMotion's Tile Mapping Primer
https://www.cosmigo.com/promotion/docs/onlinehelp/tileMappingPrimer.htm

ProMotion's Tile Mapping Data Export
https://www.cosmigo.com/promotion/docs/onlinehelp/TileMappingDataExportDlg.htm
 